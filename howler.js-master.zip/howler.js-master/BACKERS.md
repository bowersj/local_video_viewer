# Backers/Sponsors
Support the ongoing development of howler.js and get your logo on our README with a link to your site [[become a sponsor](https://github.com/sponsors/goldfire)]. You can also become a backer at a lower tier and get your name in the [BACKERS](https://github.com/goldfire/howler.js/blob/master/BACKERS.md) list. All support is greatly appreciated!

## Sponsors [[add your logo](https://github.com/sponsors/goldfire)]
[![GoldFire Studios](https://s3.amazonaws.com/howler.js/sponsors/goldfire_studios.png "GoldFire Studios")](https://goldfirestudios.com)

## Backers [[add your name](https://github.com/sponsors/goldfire)]
* James Simpson
* Spark Dev Network
